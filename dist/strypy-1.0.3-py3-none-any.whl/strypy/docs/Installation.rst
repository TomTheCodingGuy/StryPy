============
Installation
============

The recommended way to install StryPy is by using ``pip``::

    pip install strypy

Or::

    pip3 install strypy
