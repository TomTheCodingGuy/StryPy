============
Contributing
============

The easiest and arguably most useful way to contribute to StryPy is to raise issues on Github if you encounter them. To do this visit the `Issues Page <https://github.com/TomTheCodingGuy/StryPy/issues>`_

If you want to edit/contribute to code and documentation, you should fork the repository and make your changes, then submit a pull request on the latest `StryPy repository <https://github.com/TomTheCodingGuy/StryPy>`_ (main).